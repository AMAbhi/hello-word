<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" href="style.css">
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
<div class = "background">
<center>
<div class="heading"><h1>Welcome To Leave Management System</h1></div>
<form action = "admin/index.php">
<input type = "submit" value = "Admin Login" class = "admin-login shadow">
</form>
<form action = "client/index.php">
<input type = "submit" value = "Employee Login" class = "emp-login shadow">
</form>
<form action = "register.php">
<input type = "submit" value = "New Employee Registration" class = "registration shadow">
</form>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
</center>
</div>
</body>
</html>