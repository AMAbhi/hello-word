<?php
include 'connect.php';	// DB Connection
include 'mailer.php';
?>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
<link rel="stylesheet" href="style.css">
<?php
$errmsg = $sql = "";
$empname = $_POST['empname'];
$pass = $_POST['pass'];
$cnfpass = $_POST['cnfpass'];
$uname = $_POST['uname'];
$emptype = $_POST['emptype'];
$mailid = $_POST['mailid'];
$leaves = 0;
if(empty($empname) || empty($uname) || empty($pass) || empty($cnfpass) || empty($emptype) || empty($mailid))
	{
		$errmsg.="One or more fields are empty...";
	}
else{
if($pass != $cnfpass)
	{
		$errmsg.=" Passwords Don't Match...";
	}

$sql = "SELECT UserName FROM employees";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
			if($uname == $row["UserName"])
				{
					$errmsg.=" Username ".$uname." already taken...";
				}
		}
	}
if ((!filter_var($mailid, FILTER_VALIDATE_EMAIL)) || empty($mailid)) {
  $errmsg.="Invalid email ID...";
	}
}
if($emptype == "associate")
	$leaves = 180;
else if($emptype == "assistant")
	$leaves = 80;
else
	$leaves = 0;
if(!empty($errmsg))
	{
	header('location:register.php?err='.urlencode($errmsg));
	}
else
	{
		echo "<div class = 'reg-form'>";
		$sql = "INSERT INTO employees (UserName,EmpPass,EmpName,EmpType,Leaves,EmpEmail) VALUES "."('".$uname."','".$pass."','".$empname."','".$emptype."','".$leaves."','".$mailid."')";
		if ($conn->query($sql) === TRUE) {
			echo "<center>";
			echo "<strong> Registration Successful !</strong><br/><br/>";
			echo "<u>Registration Details :</u><br/>";
			echo "Username : ".$uname."<br/>";
			echo "Employee Name : ".$empname."<br/>";
			echo "Password : ".$pass."<br/>";
			echo "Employment Type : ".$emptype."<br/>";
			echo "Email id : ".$mailid."<br/>";
			echo "<form action = 'client/index.php'><input type = 'submit' value = 'Login' class = 'emp-login shadow'></form><br/>";
			$msg = "Registration Successful! \n\nUsername : ".$uname."\nEmployee Name : ".$empname."\nPassword : ".$pass."\nEmployment Type : ".$emptype."\nEmail ID : ".$mailid."\n\n\nThanks For Registering with us";
			$to = $mailid;
			$status = mailer($to,$msg);
			if($status == true)
				{
					echo "<br/>Please check your email ".$mailid." for the confirmation page.<br/>";
				}
			echo "</center>";
			echo "</div>";
		}
			else {
				echo "Error: " . $sql . "<br>" . $conn->error;
					}
$conn->close();
	}
?>