    <?php
    function testinet() 
    {
		$sCheckHost = 'www.google.com';
        return (bool) @fsockopen($sCheckHost, 80, $iErrno, $sErrStr, 5);
    }
    ?>