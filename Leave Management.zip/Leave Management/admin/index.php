<?php
if(isset($_COOKIE['adminuser']))
	{
	header('location:home.php');
	}
	else
	{	
	echo "<body>";
	echo "<div class = 'background'>";
	echo "<div class='textview'>";
	echo "<center>";
	echo "<h1>Leave Management Admin Login</h1>";
	echo "<form action = 'validator.php' method = 'post'>";
	if(isset($_GET['err']))
		{
			echo "<div class = 'error'><b><u>".$_GET['err']."</u></b></div>";
		}
	echo "<table>";
	echo "<tr><td>Username :</td><td><input type = 'text' name = 'uname' class = 'textbox shadow selected'></td></tr><br/>";
	echo "<tr><td>Password :</td><td><input type = 'password' name = 'pass' class = 'textbox shadow selected'></td></tr><br/>";
	echo "<tr><td><input type = 'submit' value = 'Login' class = 'login-button shadow'></td><br/>";
	echo "<td><input type = 'checkbox' name = 'remember'>Remember Me</td></tr><br/>";
	echo "<tr><td><a href = '../index.php'>Go Home</a></td></tr>";
	echo "</table>";
	echo "</form>";
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	echo "</center>";
	echo "</div>";
	echo "</div>";
	echo "</body>";
	}
?>
<html>
<head>
<title>::Leave Management::</title>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
</html>
