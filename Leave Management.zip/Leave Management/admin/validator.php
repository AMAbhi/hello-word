<?php
include 'connect.php';

$username = $_POST['uname'];
$password = $_POST['pass'];

$sql = "SELECT username, password FROM admins";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
        if(($username == $row["username"]) && ($password == $row["password"]))
			{
				if(isset($_POST['remember']) && (!empty($_POST['uname']) && !empty($_POST['pass'])))
					{
					$threeYear = strtotime("+3 years");
					setcookie("adminuser",$username,$threeYear);
					}
				else
					{
					setcookie("adminuser",$username,strtotime("+1 year"));
					}
			header('location:home.php');
			}
		else if (empty($username) || empty($password))
			{
			header('location:index.php?err='.urlencode('Username Or Password Empty'));
			}
		else
			{
			header('location:index.php?err='.urlencode('Username Or Password Incorrect'));
			}
    }	
?>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>