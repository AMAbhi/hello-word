<html>
<head>
<title>Search Results</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<?php
include 'connect.php';
  if(!empty($_POST['name'])){
  if(preg_match("/[A-Z  | a-z]+/", $_POST['name'])){
   $name=$_POST['name'];
   $sql="SELECT UserName, EmpName, EmpEmail, EmpType, Leaves, id FROM employees WHERE  EmpName LIKE '%" . $name . "%' OR UserName LIKE '%" . $name  ."%'";
   $result = $conn->query($sql);
   echo "<div class = 'textview'>";
	echo "<table>";
	if ($result->num_rows > 0) {
    echo "<tr><td><b>Username</b></td><td><b>Employee Name</b></td><td><b>Employee email</b></td><td><b>Employment Type</b></td><td><b>No. Of Leaves left</b></td></tr>";
		while($row = $result->fetch_assoc()) {
			echo "<tr><td>" . $row["UserName"]. "</td><td>" . $row["EmpName"]. "</td><td>" . $row["EmpEmail"]."</td><td>".$row["EmpType"]."</td><td>".$row["Leaves"]."</td><br>";
			echo "<td><a href = 'empdelete.php?id=".$row["id"]."&user=".$row["UserName"]."'>Delete This User</a></td></tr>";
			}
	echo "</table>";
	} else {
    echo "Search returned 0 results";
		}
	}
  }
  else{
	  echo "<div class = 'textview'>";
  echo  "Please enter a search query ";
  echo "<a href = 'searchemp.php'>try again?</a>";
  }
  echo "<br/><td><a href = 'index.php'>Go to Admin Home</a>";
  echo "</div>";
 ?>
</html>