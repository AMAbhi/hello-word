<?php
echo "<center>";
if(isset($_COOKIE['adminuser']))
		{
		echo "<br/><h1>Welcome " . $_COOKIE["adminuser"] ."</h1>";
	    echo "<table><tr><td><a href = 'searchemp.php'>Remove an Employee</a></td><br/><td><a href = 'logout.php'>Logout</a></td></tr><br /></table>";
		}
else
	{
		header('location:index.php');
	}
echo "</center>";
?>

<html>
<head>
<title>::Leave Management::</title>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
