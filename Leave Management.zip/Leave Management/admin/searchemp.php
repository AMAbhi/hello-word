<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
<?php
if(isset($_COOKIE['adminuser']))
	{
	echo "<div class = 'textview'>";
	echo "<center>";
	echo "<h1>Search for the employee to be deleted</h1>";
	echo "<table>";
	echo "<form method = 'post' action = 'search.php'>";
	echo "<tr><td><input type = 'text' name = 'name' class = 'textbox shadow selected'></td><td><input type = 'submit' name = 'submit' value = 'Search' class = 'login-button shadow'></td></tr>";
	echo "</form>";
	echo "<br/><tr><td><a href = 'index.php'>Go To Admin Home</a></td></tr><br/>";
	echo "</table>";
	echo "</center>";
	echo "</div>";
	}
else
	{
		header('location:index.php');
	}
?>
</body>
</html>