<?php
include 'connect.php';
$id = $_GET['id'];
$user = $_GET['user'];
$sql = "DELETE FROM employees WHERE id=".$id;
echo "<center>";
if ($conn->query($sql) === TRUE) {
    echo "<h2>Employee ".$user." was succesfully removed</h2>";
} else {
    echo "Error removing employee: " . $conn->error;
}
echo "<h4><a href = 'home.php'>Go Home</a></h4>";
echo "</center>";
$conn->close();
?>