<?php
setcookie("adminuser", "", time() - 7200);
?>
<html>
<head>
<title>::Leave Management::</title>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
<center>
<h1>Logged Out</h1>
<br/><br/>
<a href = "index.php">Login Again</a>
</center>
</body>
</html>