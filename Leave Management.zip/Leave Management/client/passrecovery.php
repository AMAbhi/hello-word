<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
<div class = 'textview'>
<center>
<h1>Recover Your Password</h1>
<?php
if(isset($_GET['err']))
	{
	echo "<div class = 'error'><b><u>".$_GET['err']."</u></b></div>";
	}
?>
<table>
<form action = 'recovery.php' method = 'post'>
<tr><td>Enter email id : </td><td><input type = 'text' name = 'recoverykey' class = 'textbox shadow selected'></td></tr>
<tr><td><input type = 'submit' value = 'Recover Password' class = 'recovery shadow'></td><td><a href = '../index.php'>Go Home</a></td><td><a href = 'index.php'>Log In</a></td></tr>
</table>
</form>
</center>
</div>
</body>
</html>