<?php
include 'connect.php';

$username = $_POST['uname'];
$password = $_POST['pass'];

$sql = "SELECT UserName, EmpPass FROM employees";
$result = $conn->query($sql);
if($result->num_rows>0){
while($row = $result->fetch_assoc()) {
        if(($username == $row["UserName"]) && ($password == $row["EmpPass"]))
			{
				if(isset($_POST['remember']) && (!empty($_POST['uname']) && !empty($_POST['pass'])))
					{
					$threeYear = strtotime("+3 years");
					setcookie("user",$username,$threeYear);
					}
				else
					{
					setcookie("user",$username,strtotime("+1 year"));
					}
			header('location:home.php');
			}
		else if (empty($username) || empty($password))
			{
			header('location:index.php?err='.urlencode('Username Or Password Empty'));
			}
		else
			{
			header('location:index.php?err='.urlencode('Username Or Password Incorrect'));
			}
    }
}
else
	{
		echo "Database Empty ! Please <a href = '../register.php'>register</a> some employees first";
	}	
?>