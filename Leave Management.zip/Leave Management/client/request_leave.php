<?php
if(isset($_COOKIE['user']))
	{
	echo "<link rel='stylesheet' type='text/css' href='style.css'>";
	echo "<center>";
	echo "<div class = 'textview'>";
	echo "<h1>Leave Request Form</h1>";
	if(isset($_GET['err']))
		{
			echo "<div class = 'error'><b><u>".$_GET['err']."</u></b></div>";
		}
	echo "<form method = 'post' action = 'request_confirm.php'>";
	echo "<br/><br/><tr><td>No Of Leave Days : </td><td><input type = 'text' name = 'leavedays' class = 'textbox shadow selected'></td></tr><br/>";
	echo "<br/><tr><td>Reason For Leave : </td></tr><br/><br/><tr><td> <textarea name='reason' rows='15' cols='30' class = 'textbox shadow selected'></textarea></td></tr><br/>";
	echo "<tr><td><input type = 'submit' value = 'Request a Leave' class = 'login-button shadow'></td><td><a href = 'home.php'>Go Home</a></td></tr><br/>";
	echo "</form>";
	echo "</center>";
	echo "</div>";
	}
	else
		{
		header('location:index.php?err='.urlencode('Please Login for Accessing this page'));
		}
	?>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>