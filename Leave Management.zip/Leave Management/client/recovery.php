<?php
include 'connect.php';
include 'recoverymailer.php';
$key = $_POST['recoverykey'];
echo "<div class = 'textview'>";
$sql = "SELECT UserName, EmpPass, EmpEmail FROM employees";
$result = $conn->query($sql);

if (!filter_var($key, FILTER_VALIDATE_EMAIL)) 
	{
	$err = "Invalid email ID";
	header('location:passrecovery.php?err='.urlencode($err));
	}

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if(($row["EmpEmail"] == $key))
			{
			$uname = $row["UserName"];
			$pass = $row["EmpPass"];
			$to = $row["EmpEmail"];
			}
    }
}
if(isset($uname) && isset($pass) && isset($to))
	{
	$msg = "The credentials for the requested account are as follows :\n\n username : ".$uname."\n password : ".$pass."\n\n\n\n Regards,\n webadmin, Project Management System";
	$status = mailer($to,$msg);
		if($status == true)
			{
			echo "Please check the mail. The password is sent there.";
			echo "<br/><a href = 'index.php'>Try logging in</a>";
			}
	}
else{
	echo "User Not Found ! <a href = 'passrecovery.php'>try again?</a>";
	}
echo "</div>";
if(empty($key))
	{
	header('location:passrecovery.php?err='.urlencode('Empty Field !'));
	}
?>
<title>::Leave Management::</title>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
<link rel="stylesheet" type="text/css" href="style.css">
