<?php
echo "<center>";
if(isset($_COOKIE['user']))
	{
       echo "<br/><h1>Welcome " . $_COOKIE["user"] ."</h1>";
	   echo "<table>";
	   echo "<tr><td><a href = 'logout.php'>Logout</a></td><br/><td><a href = 'request_leave.php'>Request a Leave</a></td></tr>";
	   echo "</table>";
	}
else
	{
		header('location:index.php');
	}
echo "</center>";
?>

<html>
<head>
<title>::Leave Management::</title>
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
