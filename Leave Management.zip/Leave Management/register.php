<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" href="style.css">
<script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
</head>
<body>
<div class="reg-form">
<center>
<h1>New Employee Registration</h1>
<i>* indicates mandatory fields</i>
<?php
if(isset($_GET['err']))
	{
		echo "<div class = 'error'><b><u>".$_GET['err']."</u></b></div>";
	}
?>
<form action = "confirm.php" method = "post">
<table>
<tr><td>* Employee Name : </td><td><input type = "text" name = "empname" class = "reg-form-fields shadow selected"></td></tr><br>
<tr><td>* Username : </td><td><input type = "text" name = "uname" class = "reg-form-fields shadow selected"></td></tr><br>
<tr><td>* Password : </td><td><input type = "password" name = "pass" class = "reg-form-fields shadow selected"></td></tr><br>
<tr><td>* Confirm Password : </td><td><input type = "password" name = "cnfpass" class = "reg-form-fields shadow selected"></td></tr><br>
<tr><td>* Employment Type : </td><td><select name = "emptype" class = "reg-form-fields shadow selected">
									<option value = "associate">Associate</option>
									<option value = "assistant">Assistant</option>
									</select>
									</td></tr><br>
<tr><td>* Employee email id : </td><td><input type = "text" name = "mailid" class = "reg-form-fields shadow selected"></td></tr><br>
<tr><td><input type = "submit" value = "Register" class = "registration shadow"></td><td><a href = "index.php">Go Home</a></td></tr>
</form>
</table>
</center>
</div>
</body>
</html>